﻿-- $manifold$
-- $include$ [OnionTopologySuiteGEOM.sql]
-- $include$ [OnionTopologySuiteWktGEOM.sql]